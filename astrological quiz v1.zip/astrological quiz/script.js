const signReadings = {
  Aries: "Bold Aries! You're entering a season of leadership and adventure.",
  Taurus: "Steady Taurus, focus on building comfort and abundance.",
  Gemini: "Curious Gemini, embrace your social energy and new ideas.",
  Cancer: "Sensitive Cancer, it's time for emotional growth and deep connections.",
  Leo: "Radiant Leo! Spotlight is on you—shine bright with confidence.",
  Virgo: "Detail-driven Virgo, organize your world and embrace self-improvement.",
  Libra: "Charming Libra, balance your relationships and seek beauty.",
  Scorpio: "Intense Scorpio, transformation and mystery await you.",
  Sagittarius: "Adventurous Sagittarius, expand your horizons and embrace freedom.",
  Capricorn: "Disciplined Capricorn, focus on goals and steady progress.",
  Aquarius: "Visionary Aquarius, connect with community and embrace innovation.",
  Pisces: "Dreamy Pisces, let your imagination guide you toward compassion."
};

document.getElementById('quiz-form').addEventListener('submit', function(event) {
  event.preventDefault();

  // Get the selected planet (ruling planet question)
  const planet = document.querySelector('input[name="planet"]:checked')?.value;

  // Get Sun, Moon, Rising signs from dropdowns
  const sunSign = document.getElementById('sun-sign').value;
  const moonSign = document.getElementById('moon-sign').value;
  const risingSign = document.getElementById('rising-sign').value;

  // Validation: Require planet and sun sign at minimum
  if (!planet || !sunSign) {
    alert('Please select your ruling planet and your Sun sign.');
    return;
  }

  // Get reading for the Sun sign
  const sunReading = signReadings[sunSign] || "Your astrological journey is unique and special!";

  // Build the result message
  const resultText = `
    <h3>Your Personalized Astrological Reading:</h3>
    <p><strong>Sun Sign:</strong> ${sunSign} — ${sunReading}</p>
    <p><strong>Ruling Planet:</strong> ${planet}</p>
    <p><strong>Moon Sign:</strong> ${moonSign || "Not selected"}</p>
    <p><strong>Rising Sign:</strong> ${risingSign || "Not selected"}</p>
  `;

  // Show the results
  const resultDiv = document.getElementById('result');
  resultDiv.innerHTML = resultText;
  resultDiv.classList.remove('hidden');

  // Show restart button
  document.getElementById('restart-btn').classList.remove('hidden');
});

document.getElementById('restart-btn').addEventListener('click', function() {
  // Reset the quiz form
  document.getElementById('quiz-form').reset();

  // Reset Sun, Moon, Rising dropdowns
  document.getElementById('sun-sign').selectedIndex = 0;
  document.getElementById('moon-sign').selectedIndex = 0;
  document.getElementById('rising-sign').selectedIndex = 0;

  // Clear and hide the results
  document.getElementById('result').innerHTML = '';
  document.getElementById('result').classList.add('hidden');

  // Hide restart button again
  this.classList.add('hidden');
});


